

<?php

// $db = mysqli_connect("localhost","root","", "colosseum");

// if(mysqli_query($db, "INSERT into bookings (firstname,lastname,specialrate,guests,bookfrom,bookto,room) 
// VALUES ('asd','asdasd','sdfsdf','123','asdasgfsd','asdasd','cdfsdf')")}{
//     echo "Done adding";
// }
// else{
//     echo "Didnt add";
// }
// echo("Something");
// echo("Something");
// echo("Something");
// echo("Something");
// echo("Something");
// echo("Something");

if(isset($_POST['submit']))
{

    $db = mysqli_connect("localhost","root","", "colosseum");




    $from = $_POST['from'];
    $to = 'badboy_666_888@inbox.ru';
    $subject = "The registration form";
    $number_guests = $_POST['submit'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $rates = $_POST['rates'];
    $room_category = $_POST['room_category'];
    $agree = $_POST['agree'];


    $body = "From :" . $from . " | " ;
    $body .="To: " . $to;
    $body .="Number of guests : " . $number_guests;
    $body .="First Name : " .  $first_name;
    $body .="Last Name : " . $last_name . " | ";
    $body .="Rates : " . $rates . " | ";
    $body .="Room Category : " . $room_category . " | ";
    $body .="Agree : Yes ";

    if(mail($to,$subject,$body))
    {
        echo("Email successfully sent to $to_email...");
    }
    else 
    {
        echo("Email sending failed...");
    }


    mysqli_query($db, "INSERT into bookings (firstname,lastname,specialrate,guests,bookfrom,bookto,room) VALUES ('$first_name','$last_name','$rates','$number_guests','$from','$to','$room_category')");
    
    echo ("Booking is added!");
}





?>










<!DOCTYPE html>
<html>

<head>
    <title>Coliseum Grand Hotel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="My Trip Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- bootstrap-css -->
    <link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <!--// bootstrap-css -->
    <!-- css -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <!--// css -->
    <!-- font-awesome icons -->
    <link href="css/font-awesome.css" rel="stylesheet">
    <!-- //font-awesome icons -->
    <!-- font -->
    <link href='//fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
    <!-- //font -->
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <!-- parallax -->
    <script src="js/SmoothScroll.min.js"></script>
    <script src="js/jarallax.js"></script>
    <!-- //parallax -->
</head>

<body>
    <!-- banner -->
    <div class="banner about-bg">
        <div class="top-banner about-top-banner">
            <div class="container">
                <div class="top-banner-left">
                    <ul>
                        <li><i class="fa fa-phone" aria-hidden="true"></i> +998 71 289-99-99</li>
                        <li><a href="mailto:info@inha.uz"><i class="fa fa-envelope" aria-hidden="true"></i>info@inha.uz</a></li>
                    </ul>
                </div>
                <div class="top-banner-right">
                    <ul>
                        <li><a class="facebook" href="https://fb.com"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a class="facebook" href="https://twitter.com"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a class="facebook" href="https://dribbble.com"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
                        <li><a class="facebook" href="https://google.com/accounts/login"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
        <div class="header">
            <div class="container">
                <div class="logo">
                    <h1>
                        <a href="index.html"> Coliseum Grand</a>
                    </h1>
                </div>
                <div class="top-nav">
                    <nav class="navbar navbar-default">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">Menu</button>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                <li><a href="index.html">Home</a></li>
                                <li><a href="about.html">About</a></li>
                                <li><a href="services.html">Services</a></li>
                                <li><a href="gallery.html">Gallery</a></li>
                                <li><a href="contact.html">Contact</a></li>
                                <div class="clearfix"> </div>
                            </ul>
                        </div>
                    </nav>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- //banner -->
    <!-- registration -->
    <div class="a-grid">
        <div class="container">
            <div class="w3l-about-heading">
                <h2>Coliseum Grand Hotel<br>Registration</h2>
            </div>
            <div class="agileits-a-about-grids">
                
  
  
  
  
 <!-------------------------------------------------------------------------------------------------------------------------------------------> 
  
  

 <form class="needs-validation" novalidate  action="" method="POST">

    <div class="form-row">
   <div class="col-md-4 mb-3">
      <label for="validationCustom01">From</label>
      <input type="email" name="from" class="form-control" id="validationCustom01" required placeholder="Enter Your emael">
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom01">to</label>
      <input type="email" name="to" class="form-control" id="validationCustom01" required value="info@inha.uz">
    </div>
    <div class="col-md-3 mb-3">
      <label for="validationCustom04">Number of guest(s)</label><br>
      <select class="form-control" id="validationCustom04" required name="number_guests">
        <option selected disabled value="">Choose...</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
      </select>
      <div class="invalid-feedback">
        Please select number of guest(s)
      </div>
    </div><br><br><br><br><br>
    <div class="col-md-4 mb-3">
      <label for="validationCustom01">First name</label>
      <input type="text" class="form-control" id="validationCustom01" placeholder="Name" required name="first_name">
      <div class="valid-feedback">
        Looks good!
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Last name</label>
      <input type="text" class="form-control" id="validationCustom02" placeholder="Last name" required name="last_name">
      <div class="valid-feedback">
        Looks good!
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <label for="validationCustom04">Special rates</label>
      <select class="form-control" id="validationCustom04" width="200px" required name="rates">
        <option selected disabled value="">Choose...</option>
        <option>None</option>
        <option>Government</option>
        <option>Veteran</option>
        <option>AAA / CAA Member</option>
        <option>Senior</option>
        <option>Special Offer Code</option>
        <option>Corporate or Group Code</option>
      </select>
      <div class="invalid-feedback">
        Please select a valid rate.
      </div>
    </div>
  </div><br><br><br><br><br>
  <div class="col-md-3 mb-3">
      <label for="validationCustom04">Room categories</label>
      <select class="form-control" id="validationCustom04" required name="room_category">
        <option selected disabled value="">Choose...</option>
        <option>Apartment</option>
        <option>Balcony</option>
        <option>Business</option>
        <option>Connected rooms</option>
        <option>Family room</option>
        <option>President</option>
        <option>Superior</option>
      </select>
      <div class="invalid-feedback">
        Please select a valid category.
      </div>
    </div>
    <div class="form-group">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required name="agree">
          <label class="form-check-label" for="invalidCheck">
            Agree to terms and conditions
          </label>
          <div class="invalid-feedback">
            You must agree before booking.
          </div>
        </div>
      </div>
      <button class="btn btn-primary" type="submit" name="submit">Book now!</button>
</form>





<!------------------------------------------------------------------------------------------------------------------------------------------->


















<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- //registration -->
    <!-- footer -->
    <div class="footer">
        <div class="container">
            <div class="footer-grids">
                <div class="col-md-3 footer-grid">
                    <div class="footer-grid-heading">
                        <h4>Address</h4>
                    </div>
                    <div class="footer-grid-info">
                        <p>INHA University in Uzbekistan
                            <span>St Ziyolilar 9</span>
                        </p>
                        <p class="phone">Phone : +998 71 289-99-99
                            <span>Email : <a href="mailto:info@inha.uz">info@inha.uz</a></span>
                        </p>
                    </div>
                </div>
                <div class="col-md-3 footer-grid">
                    <div class="footer-grid-heading">
                        <h4>Navigation</h4>
                    </div>
                    <div class="footer-grid-info">
                        <ul>
                            <li><a href="about.html">About</a></li>
                            <li><a href="services.html">Services</a></li>
                            <li><a href="gallery.html">Gallery</a></li>
                            <li><a href="contact.html">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 footer-grid">
                    <div class="footer-grid-heading">
                        <h4>Follow</h4>
                    </div>
                    <div class="social">
                        <ul>
                            <li><a href="https://fb.com"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://rss.com"><i class="fa fa-rss"></i></a></li>
                            <li><a href="https://vk.com"><i class="fa fa-vk"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-3 footer-grid">
                    <div class="footer-grid-heading">
                        <h4>Newsletter</h4>
                    </div>
                    <div class="footer-grid-info">
                        <form action="#" method="post">
                            <input type="email" id="mc4wp_email" name="EMAIL" placeholder="Enter your email here" required="">
                            <input type="submit" value="Subscribe">
                        </form>
                    </div>
                </div>
                <div class="clearfix"> </div>
            </div>
            <div class="copyright">
                <p>© 2020 IP Project . All Rights Reserved | Dasdasdesign by Big Bros <img src="images/logo.png" alt="Big Bros" width="50px" height="50px"></p>
            </div>
        </div>
    </div>
    <!-- //footer -->
</body>

</html>